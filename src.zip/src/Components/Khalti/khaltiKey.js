let myKey = {
    publicTestKey: "test_public_key_b2382ea88be1453098f577d6909cce27",
    secretKey: "test_secret_key_9c8b483123614892aeca48c14fa7ced2",
  };
  
  export default myKey;