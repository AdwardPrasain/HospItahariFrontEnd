import React, {useState, useEffect} from "react";
import KhaltiCheckout from "khalti-checkout-web";
import config from "./khaltiConfig";


export default function Khalti(props) {
  let checkout = new KhaltiCheckout(config);

  let buttonStyles = {
    color: "white",
    cursor: "pointer",
    border: "1px solid teal",
    backgroundColor: "teal",
    height: "2rem",
    borderRadius: "0.3rem",
    marginLeft: "1rem",
  };

  const [bookingData, setBookingData] = useState();

  const [bookingDetails, setBookingDetails] = useState();
  
  useEffect(()=>{
    setBookingData(props.bookingData);
    setBookingDetails(props.bookingDetails);
  },[])

  const handleClick = () => {
    localStorage.setItem("bookingData",JSON.stringify(props.bookingData));
    checkout.show({ amount: bookingData.PaymentAmount*100})

    localStorage.setItem("bookingDetails",JSON.stringify(props.bookingDetails));
   
  }
  

  return (
    <div>
      <button
        onClick={handleClick}
        style={buttonStyles}
      >
        Pay Via Khalti
      </button>
    </div>
  );
}