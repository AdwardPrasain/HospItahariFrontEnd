import React, {useState, useEffect,useContext } from 'react'
import axios from 'axios'
import { LoginContext,} from '../../Context/LoginContext'
import {Chart} from "react-google-charts"
import '../../Assets/CSS/ForAdmin/AdminDashboard.css'
import hospitalIcon from '../../Assets/Images/hospital.png'
import userIcon from '../../Assets/Images/userIcon.jpg'
import donorIcon from '../../Assets/Images/bloodDonorIcon.png'




const AdminDashboard = () => {

  const {loginDetails,setLoginDetails} = useContext(LoginContext);

/*<----- For total count box ----->*/
  const [totalCountData, setTotalCountData] = useState([]);
  
  const getTotalCountData = async () => {
      const result = await axios.get(loginDetails.URL + `/api/MainAdminDashboard/MainAdminGet`);
      setTotalCountData(result.data);
      
  };


useEffect(() => {
  getTotalCountData();

}, [loginDetails]);



/*<----- For bargraph ----->*/


 const data = [
    ["Year", "Sales", "Expenses", "Profit"],
    ["2014", 1000, 400, 200],
    ["2015", 1170, 460, 250],
    ["2016", 660, 1120, 300],
    ["2017", 1030, 540, 350],
  ];
  
  const options = {
    chart: {
      title: "Company Performance",
      subtitle: "Sales, Expenses, and Profit: 2014-2017",
    },
  };


  return (
    <div className='AdminDashboard'> {/* This  division covers overall admin dash board content */}
      
      <div className='totalCountWrapup'> {/*This division contains the content of total counts */}

      {totalCountData.map((data, index)=>( 
      <>
       <div className='totalCountContent' style={{marginLeft:'13rem'}}>
              <div style={{display:'flex', flexDirection:'row'}}>
                <img src={hospitalIcon} style={{height:'6rem', marginLeft:'0.2rem' }}/>

                <div style={{marginLeft:'0.6rem', marginTop:'2.1rem'}} >
                <h >Total Number</h>
                <p style={{fontWeight:'bold', marginLeft:'1.3rem'}}>{data.hospCount}</p>
                </div>
              </div> 
                <p style={{margin:'0.3rem'}}>Hospitals Registered</p>
          </div>

          <div className='totalCountContent'>
              <div style={{display:'flex', flexDirection:'row'}}>
                <img src={userIcon} style={{height:'5rem', marginLeft:'0.2rem' }}/>

                <div style={{marginLeft:'0.6rem', marginTop:'2.1rem'}} >
                <h >Total Number</h>
                <p style={{fontWeight:'bold', marginLeft:'1.3rem'}}>{data.userCount}</p>
                </div>
                
              </div>
              <p style={{marginLeft:'0.3rem'}}>Users Registered</p>
          </div>

          <div className='totalCountContent'>
              <div style={{display:'flex', flexDirection:'row'}}>
                <img src={donorIcon} style={{height:'6rem', marginLeft:'0.2rem' }}/>

                <div style={{marginLeft:'0.6rem', marginTop:'2.1rem'}} >
                <h >Total Number</h>
                <p style={{fontWeight:'bold', marginLeft:'1.3rem'}}>{data.donorCount}</p>
                </div>
                
              </div>
              <p style={{margin:'0.3rem'}}>Blood Donors</p>
          </div>
      </>
     
     ))}
         

      </div> {/*End of total count wrapup division */}
    
      <div className='barGraph'>{/*This division covers bargraph contents */}
          <Chart
            chartType="Bar"
            width="90%"
            height="300px"
            data={data}
            options={options}
          />
      </div> {/*End of barGraph division */}
   
    </div>/*End of main admin dashboard division */
  )
}

export default AdminDashboard