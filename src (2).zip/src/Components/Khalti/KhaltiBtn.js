import React from "react";
import KhaltiCheckout from "khalti-checkout-web";
import config from "./khaltiConfig";

export default function Khalti() {
  let checkout = new KhaltiCheckout(config);

  let buttonStyles = {
    color: "white",
    cursor: "pointer",
    border: "1px solid teal",
    backgroundColor: "teal",
    height: "2rem",
    borderRadius: "0.3rem",
    marginLeft: "1rem",
  };
  return (
    <div>
      <button
        onClick={() => checkout.show({ amount: 10000 })}
        style={buttonStyles}
      >
        Pay Via Khalti
      </button>
    </div>
  );
}